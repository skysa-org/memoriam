---
days:
  2026-10-12~zz: { words: 9, passes: 1, reviews: 0, started: 9, ms: 4000 }
---
